### LEIA ISTO PROFESSORA!

Para executar o arquivo corretamente, é recomendado baixar o arquivo em formato '.zip'.

### Como baixar?

Ao abrir o link do repositório, clique no botão verde escrito "<> Code". Em seguida, clique no botão "Download ZIP".
Após a instalação do arquivo, extraia ele para uma pasta, e execute-o.
